import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiheadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads):
        super(MultiheadAttention, self).__init__()
        assert embed_dim % num_heads == 0, "Embedding dimension must be divisible by number of heads"
        
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        
        # Linear layers for Q, K, V
        self.linear_q = nn.Linear(embed_dim, embed_dim)
        self.linear_k = nn.Linear(embed_dim, embed_dim)
        self.linear_v = nn.Linear(embed_dim, embed_dim)
        
        # Final linear layer
        self.final_linear = nn.Linear(embed_dim, embed_dim)
        
        # Dropout layer
        self.dropout = nn.Dropout(p=0.1)

    def scaled_dot_product_attention(self, query, key, value):
        # Calculate the dot product
        scores = torch.matmul(query, key.transpose(-2, -1)) / (self.head_dim ** 0.5)
        
        # Apply softmax to get attention scores
        attn = F.softmax(scores, dim=-1)
        
        # Apply dropout
        attn = self.dropout(attn)
        
        # Multiply by value
        output = torch.matmul(attn, value)
        return output

    def forward(self, query, key, value):
        batch_size = query.size(0)
        
        # Perform linear operation and split into h heads
        
        query_l = self.linear_q(query)
        query = query_l.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        key = self.linear_k(key).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        value = self.linear_v(value).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Apply scaled dot product attention
        attn_output = self.scaled_dot_product_attention(query, key, value)
        
        # Concatenate heads and put through final linear layer
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, -1, self.embed_dim)
        # combine and redistribute with a final layer
        output = self.final_linear(attn_output)
        
        return output

# Assuming the MultiheadAttention class is already defined as shown in the previous example

# Set the random seed for reproducibility
torch.manual_seed(0)

# Define the dimensions
embed_dim = 768  # Embedding size for each token
num_heads = 16  # Number of attention heads
seq_length = 2000  # Length of the sequence

# Create an instance of MultiheadAttention

#multihead_attn = MultiheadAttention(embed_dim, num_heads)


#multihead_attn = nn.MultiheadAttention(embed_dim, num_heads, batch_first=True)


device='cuda'
num_new_heads = num_heads * 2
head_dim = embed_dim // num_new_heads

from rotary import RotaryEmbedding
rotary_emb = RotaryEmbedding(
        head_dim,
        base=10000.0,
        interleaved=True,
        device=device,
    )
rotary_emb._update_cos_sin_cache(seq_length, device=device, dtype= torch.float16)
rel_pos = (rotary_emb._cos_cached, rotary_emb._sin_cached)



from mha import MHA
#multihead_attn = MHA(embed_dim, num_heads)

from multihead_flashdiff_3 import MultiheadFlashDiff3

multihead_attn = MultiheadFlashDiff3(embed_dim, num_heads )


multihead_attn.to(device, dtype=torch.float16)

# Simulate a batch of token embeddings (batch size = 1)
token_embeddings = torch.randn(10, seq_length, embed_dim).to(device, dtype=torch.float16)

# Apply the MultiheadAttention layer (self-attention)
import time
t1 = time.time()

for i in range(1000):
    #output = multihead_attn( token_embeddings, token_embeddings, token_embeddings)
    output = multihead_attn( token_embeddings, rel_pos )

print(f"Time of taken: {time.time() - t1:.3f} s")



#print("Input Embeddings:")
#print(token_embeddings)
#print("\nOutput of Multihead Attention:")
#print(output)


