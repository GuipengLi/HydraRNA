import torch

from multihead_flashdiff_1 import MultiheadFlashDiff1
#from multihead_flashdiff_3x import MultiheadFlashDiff3
from dataclasses import dataclass



device = torch.device("cuda")
torch.cuda.reset_peak_memory_stats(device)
torch.cuda.synchronize()

dtype = torch.float16

seq_len = 2**10

head_dim = 16

x = torch.randn(2, seq_len, 768, device=device, dtype = torch.float16)


@dataclass
class Args:
    model_parallel_size: int
    decoder_kv_attention_heads: int

args = Args(model_parallel_size=1, decoder_kv_attention_heads=4)

from flash_attn.layers.rotary import RotaryEmbedding

rotary_emb = RotaryEmbedding(
        head_dim,
        base=10000.0,
        interleaved=True,
        device=device,
    )

rotary_emb._update_cos_sin_cache(seq_len, device=device, dtype=torch.float16)
rel_pos = (rotary_emb._cos_cached, rotary_emb._sin_cached)



model = MultiheadFlashDiff1(args = args, embed_dim=768, depth=12, num_heads=16)
model.to(device, dtype=dtype)
y = model(x, rel_pos)

print(y.shape)
